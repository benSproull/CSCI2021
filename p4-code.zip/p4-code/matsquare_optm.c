// optimized versions of matrix diagonal summing
#include "matvec.h"

#define MGET(mat,i,j) ((mat).data[((i)*((mat).cols)) + (j)])
#define VGET(vec,i)   ((vec).data[(i)])

#define MSET(mat,i,j,x) ((mat).data[((i)*((mat).cols)) + (j)] = (x))
#define VSET(vec,i,x)   ((vec).data[(i)] = (x))

int matsquare_VER1(matrix_t *mat, matrix_t *matsq) {
  // for(int i = 0; i < mat->rows; i++){
  //   for(int j = 0; j < mat->rows; j++){
  //     mset(matsq,i,j,0);
  //     for(int k = 0; k < mat->rows; k++){
  //       int mik = mget(mat, i, k);
  //       int mkj = mget(mat, k, j);
  //       int cur = mget(matsq, i, j);
  //       int new = cur + mik*mkj;
  //       mset(matsq, i, j, new);
  //     }
  //   }
  // }

  matrix_t mato = *mat;
  matrix_t matsqo = *matsq;

  for(int i = 0; i < mato.rows; i++){
    for(int j = 0; j < mato.cols; j++){
      MSET(*matsq, i, j, 0);
    }
  }
  for(int x = 0; x < mato.rows; x++){    
    for(int y = 0; y < mato.cols; y++){
      int head = MGET(mato, x, y);
      int z = 0;
      for(; z < mato.cols - 2; z+=3){
          int temp1 = MGET(matsqo, x, z);
          int temp2 = MGET(matsqo, x, z+1);
          int temp3 = MGET(matsqo, x, z+2); 
          //int temp4 = MGET(*matsq, x, z+3);

          
          int new1 = MGET(mato, y, z);
          int new2 = MGET(mato, y, z+1);
          int new3 = MGET(mato, y, z+2);
          //int new4 = MGET(*mat, y, z+3);


          temp1 += head * new1;
          temp2 += head * new2;
          temp3 += head * new3;
          //temp4 += head * new4;


          MSET(matsqo, x, z, temp1);
          MSET(matsqo, x, z+1, temp2);
          MSET(matsqo, x, z+2, temp3);
          //MSET(*matsq, x, z+3, temp4);

      }
      
      for( ; z < mato.cols; z++){
        int temp = MGET(matsqo, x, z);
        int new = MGET(mato, y, z);
        temp += head * new;
        MSET(matsqo, x, z, temp);
      }
    }
  }
  return 0;
}

int matsquare_VER2(matrix_t *mat, matrix_t *matsq) {
  // OPTIONALLY, OTHER VERSIONS
  return 0;
}


int matsquare_OPTM(matrix_t *mat, matrix_t *matsq){
  if(mat->rows != mat->cols   ||      // must be a square matrix to square it
     mat->rows != matsq->rows ||
     mat->cols != matsq->cols)
  {
    printf("matsquare_OPTM: dimension mismatch\n");
    return 1;
  }

  // Call to some version of optimized code
  return matsquare_VER1(mat, matsq);
}
/////////////////////////////////////////////////////////////////////////////////
// ADDITIONAL INFORMATION
//
// (A) VERSION: If you implemented several versions, indicate which
// version you timed
// 
// ####################### YOUR ANSWER HERE #########################
//    Only used matsquare_VER1
// ##################################################################
// 
//
// (B) TIMING ON loginNN.cselabs.umn.edu:
// Paste a copy of the results of running matsquare_benchmark on the
// above machines in the space below which shows how your performance
// optimizations improved on the baseline codes.
// 
// ####################### YOUR ANSWER HERE #########################
//    ==== Matrix Square Benchmark Version 2 ====
  // SIZE       BASE       OPTM  SPDUP   LOG2  SCALE POINTS 
  //  256 3.8060e-01 4.7669e-02   7.98   3.00   0.94   2.81 
  //  273 3.9459e-01 5.6458e-02   6.99   2.81   1.00   2.81 
  //  512 3.7323e+00 3.7586e-01   9.93   3.31   1.88   6.21 
  //  801 1.1711e+01 1.4475e+00   8.09   3.02   2.93   8.85 
  // 1024 3.9130e+01 2.9284e+00  13.36   3.74   3.75  14.03 
  // RAW POINTS: 34.71
  // TOTAL POINTS: 30 / 30
// ##################################################################
// 
// (C) OPTIMIZATIONS:
// Describe in some detail the optimizations you used to speed the code
// up.  THE CODE SHOULD CONTAIN SOME COMMENTS already to describe these
// but in the section below, describe in English the techniques you used
// to make the code run faster.  Format your descriptions into discrete
// chunks such as.
// 
// Optimization 1: Blah bla blah... This should make run faster because
// yakkety yakeety yak.
// 
// Optimization 2: Blah bla blah... This should make run faster because
// yakkety yakeety yak.
// ...
// Optimization N: Blah bla blah... This should make run faster because
// yakkety yakeety yak.
// 
// Full credit solutions will describe 2-3 optimizations and describe
// WHY these improved performance in at least a couple sentences.
// 
// ####################### YOUR ANSWER HERE #########################
//  Optimization 1: Loop unrolling inorder to allow more procedures to happen in a shorter amount of time
//
//  Optimization 2: Putting the macros into this program so they are saved locally
//
//  Optimization 3: Putting the matrix_t struct into locally saved registers to allow access to those variables
// ##################################################################
